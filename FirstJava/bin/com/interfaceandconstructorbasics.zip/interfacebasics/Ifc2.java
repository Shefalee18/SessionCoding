package com.interfacebasics;

public interface Ifc2 extends Ifc3{
	public static final int ifc2_y=5;
	public abstract int sub(int x,int y);
}
