package com.interfacebasics;

public interface Ifc3 {
	public abstract int mult(int x,int y);

}
