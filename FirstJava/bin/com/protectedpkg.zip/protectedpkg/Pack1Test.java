package com.protectedpkg;

public class Pack1Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pack1 pack1 = new Pack1();
		pack1.method1();
		pack1.method2();
	}

}
