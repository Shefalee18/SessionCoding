package com.protectedpkg;

public class Pack1 {
	public void method1(){
	 System.out.println("Inside method1");
	}
	 protected void  method2(){
	 System.out.println("Inside method2");
	 }
 }
